Lightweight File Manager (Windows x64) - Version 0.2.0

使い方
1. ZIP の内容をすべて同じフォルダーに展開します。
2. lightweight-file-manager.exe を起動します。
3. Visual C++ ランタイムが不足している場合は、vc_redist.x64.exe を実行してインストールしてください。

Qt 6.12 の実行用 DLL とプラグインはこのフォルダーに含まれます。DLL とサブフォルダーを exe から分離しないでください。Visual C++ ランタイムは Microsoft の公式インストーラーを同梱しています。

Qt は動的リンクで使用しています。Qt のライセンスと著作権情報は licenses フォルダー内にあります。アプリのソースコードは次のリポジトリで公開しています。
https://github.com/nkgw0521/LightweightFileManager

