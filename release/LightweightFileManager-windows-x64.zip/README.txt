Lightweight File Manager - Windows x64

1. Extract this ZIP to a folder.
2. If the app reports a missing Visual C++ runtime, run vc_redist.x64.exe and choose Install (or Repair).
3. Start lightweight-file-manager.exe.

Keep the DLL files and subfolders next to the executable. They are required Qt runtime libraries and plugins.
